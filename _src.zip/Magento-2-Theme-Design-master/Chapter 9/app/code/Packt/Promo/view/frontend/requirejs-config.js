var config = {
    "map":{
        "*":{
          promo: "Packt_Promo/js/promo"
        }
    },

    "shim": {
      "Packt_Promo/js/jquery.jcarousel-core.min": ["jquery"],
      "Packt_Promo/js/jquery.jcarousel-control.min": ["jquery"],
      "Packt_Promo/js/jquery.jcarousel-pagination.min": ["jquery"]
    }
};
