<?php
namespace Packt\Promo\Block;

/**
* Promo block
*/
class Promo
    extends \Magento\Framework\View\Element\Template
{
    public function getTitle()
    {
        return "My Promotions Block";
    }
}
